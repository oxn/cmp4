/**
 * Content utility functions
 * Corresponds to Typecho's Widget/Base/Contents.php
 */
import { renderPermalinkPattern } from '@/lib/permalink-pattern';

/**
 * Generate a URL-safe slug from a string
 */
export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fff\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .substring(0, 150);
}

/**
 * Build a permalink for a content item
 * Supports dynamic permalink patterns from options.permalinkPattern
 *
 * Pattern variables:
 *   {cid}      - Content ID
 *   {slug}     - URL slug
 *   {category} - Primary category slug
 *   {year}     - 4-digit year
 *   {month}    - 2-digit month
 *   {day}      - 2-digit day
 */
export function buildPermalink(
  content: {
    cid: number;
    slug: string | null;
    type: string | null;
    created: number | null;
    category?: string | null;
  },
  siteUrl: string,
  pattern?: string | null,
  pagePattern?: string | null,
): string {
  const base = siteUrl.replace(/\/$/, '');

  // Pages use pagePattern (default: /{slug}.html)
  if (content.type === 'page' || content.type === 'page_draft') {
    const pgPattern = pagePattern || '/{slug}.html';
    const url = renderPermalinkPattern(pgPattern, 'page', {
      cid: content.cid,
      slug: content.slug || String(content.cid),
    }) ?? `/${content.slug || content.cid}.html`;
    return `${base}${url}`;
  }

  // Attachments always use fixed pattern
  if (content.type === 'attachment') {
    return `${base}/attachment/${content.cid}/`;
  }

  // For posts, use the configured pattern (default: /archives/{cid}/)
  const postPattern = pattern || '/archives/{cid}/';

  // Build date parts from created timestamp
  const date = content.created ? new Date(content.created * 1000) : new Date();
  const year = String(date.getFullYear());
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  const url = renderPermalinkPattern(postPattern, 'post', {
    cid: content.cid,
    slug: content.slug || String(content.cid),
    category: content.category || 'uncategorized',
    year,
    month,
    day,
  }) ?? `/archives/${content.cid}/`;

  return `${base}${url}`;
}

function normalizePathForRedirect(pathname: string): string {
  if (pathname === '/') return pathname;
  return pathname.replace(/\/+$/, '');
}

/**
 * Return a safe redirect target only when it differs from the current URL.
 * This prevents route handlers from issuing a 302 to the same canonical path.
 */
export function getRedirectPathIfDifferent(currentUrl: string, targetUrl: string): string | null {
  const current = new URL(currentUrl, 'http://typecho.local');
  const target = new URL(targetUrl, current.origin);

  const currentPath = normalizePathForRedirect(current.pathname);
  const targetPath = normalizePathForRedirect(target.pathname);

  if (currentPath === targetPath && current.search === target.search) {
    return null;
  }

  return `${target.pathname}${target.search}${target.hash}`;
}

/**
 * Build category permalink
 * Supports custom category path patterns.
 * Pattern variables:
 *   {slug}     - Category slug
 *   {mid}      - Category ID
 */
export function buildCategoryLink(
  slug: string,
  siteUrl: string,
  categoryPattern?: string | null,
  mid?: number | null,
): string {
  const base = siteUrl.replace(/\/$/, '');
  const pattern = categoryPattern || '/category/{slug}/';
  const url = renderPermalinkPattern(pattern, 'category', { slug, mid })
    ?? `/category/${slug}/`;
  return `${base}${url}`;
}

/**
 * Build tag permalink
 */
export function buildTagLink(slug: string, siteUrl: string): string {
  return `${siteUrl.replace(/\/$/, '')}/tag/${slug}/`;
}

/**
 * Build author permalink
 */
export function buildAuthorLink(uid: number, siteUrl: string): string {
  return `${siteUrl.replace(/\/$/, '')}/author/${uid}/`;
}

/**
 * Build date archive permalink
 */
export function buildDateLink(
  year: number,
  month?: number,
  day?: number,
  siteUrl = ''
): string {
  const base = siteUrl.replace(/\/$/, '');
  if (day && month) {
    return `${base}/${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}/`;
  }
  if (month) {
    return `${base}/${year}/${String(month).padStart(2, '0')}/`;
  }
  return `${base}/${year}/`;
}

/**
 * Build search permalink
 */
export function buildSearchLink(keywords: string, siteUrl: string): string {
  return `${siteUrl.replace(/\/$/, '')}/search/${encodeURIComponent(keywords)}/`;
}

/**
 * Format a Unix timestamp using PHP-style date formatting
 * Supports the PHP date format characters used by Typecho settings.
 */
export function formatDate(timestamp: number, format: string, timezoneOffset = 28800): string {
  const numericTimestamp = Number(timestamp);
  const numericOffset = Number(timezoneOffset);
  const offset = Number.isFinite(numericOffset) ? numericOffset : 28800;
  const date = new Date((numericTimestamp + offset) * 1000);
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  const hour = date.getUTCHours();
  const minute = date.getUTCMinutes();
  const second = date.getUTCSeconds();
  const dayOfWeek = date.getUTCDay();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const dayOfYear = Math.floor((Date.UTC(year, month - 1, day) - Date.UTC(year, 0, 1)) / 86400000);
  const ordinal = day % 10 === 1 && day % 100 !== 11
    ? 'st'
    : day % 10 === 2 && day % 100 !== 12
      ? 'nd'
      : day % 10 === 3 && day % 100 !== 13
        ? 'rd'
        : 'th';
  const values: Record<string, string> = {
    Y: String(year), y: String(year).slice(-2),
    m: String(month).padStart(2, '0'), n: String(month),
    d: String(day).padStart(2, '0'), j: String(day), S: ordinal,
    H: String(hour).padStart(2, '0'), G: String(hour),
    h: String(hour % 12 || 12).padStart(2, '0'), g: String(hour % 12 || 12),
    i: String(minute).padStart(2, '0'), s: String(second).padStart(2, '0'),
    a: hour < 12 ? 'am' : 'pm', A: hour < 12 ? 'AM' : 'PM',
    F: monthNames[month - 1], M: monthNames[month - 1].slice(0, 3),
    D: dayNames[dayOfWeek].slice(0, 3), l: dayNames[dayOfWeek],
    N: String(dayOfWeek || 7), w: String(dayOfWeek),
    t: String(daysInMonth), z: String(dayOfYear),
    c: new Date(numericTimestamp * 1000).toISOString(), U: String(Math.floor(numericTimestamp)),
  };

  // Single-pass replacement: match either an escaped char (\X) or a format letter (X).
  // This prevents substituted values from being re-processed by subsequent replacements.
  return String(format || 'Y-m-d H:i').replace(/\\(.)|(Y|y|m|n|d|j|S|H|G|h|g|i|s|a|A|F|M|D|l|N|w|t|z|c|U)/g, (match, escaped, token) => {
    if (escaped !== undefined) {
      // \X — output the literal character X (strips the backslash)
      return escaped;
    }
    return values[token] ?? match;
  });
}

/**
 * Calculate reading time in minutes
 */
export function calculateReadingTime(text: string): number {
  const wordCount = text.replace(/<[^>]+>/g, '').length;
  // Assume ~500 chars/min for Chinese, ~200 words/min for English
  return Math.max(1, Math.ceil(wordCount / 500));
}

/**
 * Parse content type from the `type` field
 */
export function getContentType(type: string | null): 'post' | 'page' | 'attachment' | 'draft' {
  if (!type) return 'post';
  if (type.endsWith('_draft')) return 'draft';
  if (type === 'page') return 'page';
  if (type === 'attachment') return 'attachment';
  return 'post';
}
