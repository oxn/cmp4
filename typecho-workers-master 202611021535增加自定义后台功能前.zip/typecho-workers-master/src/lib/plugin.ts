/**
 * Plugin system - discovers and manages plugins from npm packages
 * 
 * Plugin packages are identified by their package.json keywords
 * containing both "typecho" and "plugin".
 * 
 * Hook types (following Typecho conventions):
 * - call: Action hooks - execute side effects at specific points
 * - filter: Filter hooks - transform data through a chain of handlers
 * 
 * Plugin package structure:
 *   typecho-plugin-example/
 *     package.json       - Must have keywords: ["typecho", "plugin"] + typecho.plugin manifest
 *     index.ts/js        - Plugin entry point (required)
 */

// ==================== Types ====================

/**
 * Plugin configuration field definition.
 * Mirrors PHP Typecho's Form Element types (Text, Textarea, Select, Radio, Checkbox, Password, Hidden).
 */
export interface PluginConfigField {
  /** Field type */
  type: 'text' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'password' | 'hidden' | 'repeatable';
  /** Display label */
  label: string;
  /** Help text / description shown below the field */
  description?: string;
  /** Default value */
  default?: unknown;
  /** Options for select / radio / checkbox: { value: label } */
  options?: Record<string, string>;
  /** Render each radio or multi-value checkbox option on its own line. */
  multiline?: boolean;
  /** Dynamic option source for select fields */
  optionsSource?: 'r2Bindings';
  /** Conditional visibility inside repeatable config groups */
  showWhen?: {
    field: string;
    value: string | string[];
  };
  /** Nested fields for repeatable config groups */
  itemFields?: Record<string, PluginConfigField>;
}

export interface PluginManifest {
  /** Unique plugin identifier */
  id: string;
  /** Display name */
  name: string;
  /** Plugin description */
  description?: string;
  /** Author name */
  author?: string;
  /** Author URL */
  authorUrl?: string;
  /** Plugin version */
  version?: string;
  /** Plugin homepage / repository URL */
  homepage?: string;
  /** License */
  license?: string;
  /** Tags for categorization */
  tags?: string[];
  /** Required Typecho version */
  requires?: string;
  /**
   * Optional slug handled by the generic /admin/plugin/[slug] container.
   * The container resolves its document title from this plugin's name
   * (or `adminPageTitle` when set).
   */
  adminPage?: string;
  /**
   * Optional document title for `/admin/plugin/<adminPage>`.
   * When omitted, falls back to the plugin name (or `${name} 设置` if
   * `adminPageIsSettings` is true).
   */
  adminPageTitle?: string;
  /**
   * When true (and `adminPage` is set), the plugins list 「设置」link
   * points at `/admin/plugin/<adminPage>` instead of (or in preference to)
   * the declarative `/admin/plugin-config` form. Use for custom settings UIs
   * that omit `config` (e.g. Notifier). Ops-only admin pages (Notes, Cache)
   * leave this unset so 「设置」is not shown.
   */
  adminPageIsSettings?: boolean;
  /** Load a named earlyRequestProvider before the normal D1 bootstrap. */
  earlyRequest?: boolean;
  /**
   * Plugin configuration fields.
   * If present, the admin panel shows a "设置" link for this plugin
   * (unless `adminPageIsSettings` redirects that link to `adminPage`).
   * Keys are field names, values are field definitions.
   * Stored as JSON in options table under key "plugin:<id>".
   */
  config?: Record<string, PluginConfigField>;
}

export interface PluginInfo {
  /** Plugin ID (slug) */
  id: string;
  /** npm package name */
  packageName: string;
  /** Plugin manifest from package.json's typecho.plugin */
  manifest: PluginManifest;
  /** Whether this plugin is currently activated */
  isActive: boolean;
}

/**
 * Hook handler function types
 * - CallHandler: Receives context, no return value expected
 * - FilterHandler: Receives value + context, must return the (possibly modified) value
 */
export type CallHandler = (...args: any[]) => void | Promise<void>;
export type FilterHandler = (value: any, ...args: any[]) => any | Promise<any>;

export interface HookContext {
  activatedPlugins: Set<string>;
}

export interface PluginInitContext {
  addHook: typeof addHook;
  HookPoints: typeof HookPoints;
  pluginId: string;
}

export interface PluginRouteResult {
  handled?: boolean;
  response?: Response;
}

interface HookRegistration {
  pluginId: string;
  handler: CallHandler | FilterHandler;
  priority: number;
}

// ==================== Hook Definitions ====================

/**
 * Complete hook point definitions, mapped from Typecho's original plugin system.
 * 
 * Naming convention: component:hookName
 * - Components map to Typecho's Widget classes
 * - Hook names match original Typecho names where applicable
 */
export const HookPoints = {
  // --- Core System ---
  'system:begin': 'system:begin',                    // System startup
  'system:end': 'system:end',                        // System shutdown
  'route:request': 'route:request',                  // Filter: custom plugin route handling

  // --- Admin UI ---
  'admin:header': 'admin:header',                    // Admin head section (inject CSS/meta)
  'admin:footer': 'admin:footer',                    // Admin footer (inject JS)
  'admin:navBar': 'admin:navBar',                    // Admin navigation extension
  'admin:begin': 'admin:begin',                      // Admin page begin
  'admin:end': 'admin:end',                          // Admin page end
  'admin:loginHead': 'admin:loginHead',              // Filter: HTML injected into login page <head>
  'admin:loginForm': 'admin:loginForm',              // Filter: HTML injected into login page form

  // --- Content Editing (Admin) ---
  'admin:writePost:option': 'admin:writePost:option',          // Post editor sidebar options
  'admin:writePost:advanceOption': 'admin:writePost:advanceOption', // Post editor advanced options
  'admin:writePost:bottom': 'admin:writePost:bottom',          // Post editor bottom area
  'admin:managePosts:titleActions': 'admin:managePosts:titleActions', // Post list title inline actions
  'admin:writePage:option': 'admin:writePage:option',          // Page editor sidebar options
  'admin:writePage:advanceOption': 'admin:writePage:advanceOption', // Page editor advanced options
  'admin:writePage:bottom': 'admin:writePage:bottom',          // Page editor bottom area
  'admin:profile:bottom': 'admin:profile:bottom',              // Profile page bottom area
  'plugin:config:beforeSave': 'plugin:config:beforeSave',      // Filter: validate or normalize plugin config before saving

  // --- Content Display (Frontend) ---
  'archive:select': 'archive:select',               // Filter: DB query for content listing
  'archive:handleInit': 'archive:handleInit',        // After content init
  'archive:header': 'archive:header',                // Frontend head section
  'archive:footer': 'archive:footer',                // Frontend footer section
  'archive:beforeRender': 'archive:beforeRender',    // Before template render
  'archive:afterRender': 'archive:afterRender',      // After template render
  'archive:indexHandle': 'archive:indexHandle',       // Index page processing
  'archive:singleHandle': 'archive:singleHandle',    // Single post/page processing
  'archive:categoryHandle': 'archive:categoryHandle', // Category archive processing
  'archive:tagHandle': 'archive:tagHandle',          // Tag archive processing
  'archive:searchHandle': 'archive:searchHandle',    // Search results processing

  // --- Content Filtering ---
  'content:filter': 'content:filter',                // Filter: raw content row data
  'content:title': 'content:title',                  // Filter: content title
  'content:excerpt': 'content:excerpt',              // Filter: content excerpt/summary
  'content:markdown': 'content:markdown',            // Filter: Markdown processing
  'content:content': 'content:content',              // Filter: rendered HTML content

  // --- Comment Filtering ---
  'comment:filter': 'comment:filter',                // Filter: raw comment row data
  'comment:content': 'comment:content',              // Filter: rendered comment content
  'comment:markdown': 'comment:markdown',            // Filter: comment Markdown
  'comment:allowContent': 'comment:allowContent',    // Filter: custom content type comment eligibility
  'comment:avatarMap': 'comment:avatarMap',          // Filter: public comment avatar URL map
  'comment:list': 'comment:list',                    // Filter: public comment list API payload extension
  'gravatar:url': 'gravatar:url',                    // Filter: single Gravatar URL (CDN rewrite etc.)

  // --- Content Management ---
  'post:write': 'post:write',                        // Filter: post data before save
  'post:finishPublish': 'post:finishPublish',        // After post published
  'post:finishSave': 'post:finishSave',              // After post saved (draft or publish)
  'post:delete': 'post:delete',                      // Before post delete
  'post:finishDelete': 'post:finishDelete',          // After post deleted
  'page:write': 'page:write',                        // Filter: page data before save
  'page:finishPublish': 'page:finishPublish',        // After page published
  'page:finishSave': 'page:finishSave',              // After page saved
  'page:delete': 'page:delete',                      // Before page delete
  'page:finishDelete': 'page:finishDelete',          // After page deleted

  // --- Comment Management ---
  'feedback:comment': 'feedback:comment',            // Filter: comment data before save
  'feedback:finishComment': 'feedback:finishComment', // After comment saved
  'feedback:reply': 'feedback:reply',                // On comment reply
  'comment:action': 'comment:action',                // Call: comment moderation action applied

  // --- User System ---
  'user:login': 'user:login',                        // Login attempt
  'user:loginSucceed': 'user:loginSucceed',          // Login success
  'user:loginFail': 'user:loginFail',                // Login failure
  'user:logout': 'user:logout',                      // User logout
  'user:register': 'user:register',                  // Filter: registration data
  'user:finishRegister': 'user:finishRegister',      // After registration

  // --- File Upload ---
  'upload:beforeUpload': 'upload:beforeUpload',      // Before file upload
  'upload:upload': 'upload:upload',                  // After file uploaded
  'upload:delete': 'upload:delete',                  // File deletion

  // --- Feed ---
  'feed:item': 'feed:item',                          // Filter: feed item data
  'feed:generate': 'feed:generate',                  // Filter: complete feed XML

  // --- Sidebar / Widgets ---
  'widget:sidebar': 'widget:sidebar',                // Filter: sidebar data

  // --- Security headers ---
  'csp:directives': 'csp:directives',                // Filter: CSP directives map (G3-5)

  // --- Mail ---
  'mail:send': 'mail:send',                          // Filter: mail sending (plugin adapter)
} as const;

export type HookPoint = typeof HookPoints[keyof typeof HookPoints];

// ==================== Plugin Registry ====================

/**
 * Module-level state — safe in Cloudflare Workers because:
 * 1. Workers are single-threaded: only one request executes at a time per isolate
 * 2. pluginRegistry and hookRegistry are populated once at module init (build time)
 *    and are effectively read-only at runtime
 * 3. Per-request state (activatedPlugins) lives on RequestContext and is passed
 *    explicitly as the first argument to hook functions.
 */

/**
 * Registry of all discovered plugins
 * Key: plugin ID, Value: PluginInfo
 */
const pluginRegistry = new Map<string, PluginInfo>();

/**
 * Hook handlers registry
 * Key: hook point name, Value: sorted array of handlers
 */
const hookRegistry = new Map<string, HookRegistration[]>();

// ── Lazy initialiser table (G6-3) ────────────────────────────────────────
// Populated at module load by plugin-loader's injected
// `registerPluginLoaders` call. Initialisation and module evaluation are
// deferred to `setActivatedPlugins`, so disabled plugins stay out of the
// isolate startup path.

type PluginInitFn = (ctx: PluginInitContext) => void | Promise<void>;
type PluginInitLoader = () => PluginInitFn | Promise<PluginInitFn>;
const pluginInitLoaders = new Map<string, PluginInitLoader>();
const initialisedPlugins = new Set<string>();
const initialisingPlugins = new Map<string, Promise<void>>();
let pluginInitContext: { addHook: typeof addHook; HookPoints: typeof HookPoints } | null = null;

/**
 * Plugins can register admin paths that bypass the reserved-core-path guard
 * in middleware. Call this during plugin init() for each /admin/ or /api/admin/
 * path the plugin serves via route:request.
 *
 * G: registration is restricted to /admin/ and /api/admin/ prefixed paths.
 * isReservedCorePath() in middleware exempts any registered path from the
 * hard block, so accepting arbitrary paths (e.g. /api/users/login,
 * /api/install) would let a buggy or malicious plugin shadow authentication,
 * installation or other core flows.
 */
const PLUGIN_ADMIN_PATH_PREFIXES = ['/admin/', '/api/admin/'] as const;
const pluginAdminPaths = new Set<string>();

export function registerPluginAdminPath(path: string): void {
  if (!PLUGIN_ADMIN_PATH_PREFIXES.some(prefix => path.startsWith(prefix))) {
    console.warn(
      `[plugin] registerPluginAdminPath rejected "${path}": only /admin/ and /api/admin/ paths may bypass the reserved-core-path guard`,
    );
    return;
  }
  pluginAdminPaths.add(path);
}

export function isPluginAdminPath(path: string): boolean {
  return pluginAdminPaths.has(path);
}

/**
 * Backward-compatible registration Interface for tests and integrations that
 * already imported plugin init functions.
 */
export function registerPluginInit(
  inits: Record<string, PluginInitFn>,
  ctx: { addHook: typeof addHook; HookPoints: typeof HookPoints },
): void {
  registerPluginLoaders(
    Object.fromEntries(
      Object.entries(inits).map(([id, init]) => [id, () => init]),
    ),
    ctx,
  );
}

/**
 * Register deferred module loaders generated by plugin-loader. Keeping the
 * loader behind this Interface prevents disabled plugin modules from being
 * evaluated during isolate startup.
 */
export function registerPluginLoaders(
  loaders: Record<string, PluginInitLoader>,
  ctx: { addHook: typeof addHook; HookPoints: typeof HookPoints },
): void {
  pluginInitContext = ctx;
  for (const [id, loader] of Object.entries(loaders)) {
    pluginInitLoaders.set(id, loader);
  }
}

// ==================== Plugin Management ====================

/**
 * Register a plugin into the registry.
 * Called by the plugin-loader integration at build time.
 */
export function registerPlugin(
  packageName: string,
  manifest: PluginManifest,
): void {
  const id = manifest.id || packageName;
  pluginRegistry.set(id, {
    id,
    packageName,
    manifest: { ...manifest, id },
    isActive: false,
  });
}

/**
 * Set the list of activated plugin IDs (loaded from DB).
 *
 * G6-3: the first time we see a given plugin in the activated set, we
 * call its init function so its hooks land in hookRegistry. Plugins
 * that are never activated never have their init code run, which keeps
 * the per-isolate startup cost proportional to active plugin count.
 */
export async function setActivatedPlugins(ctx: HookContext, ids: string[]): Promise<void> {
  ctx.activatedPlugins = new Set(ids);
  if (!pluginInitContext) return;
  for (const id of ids) {
    if (initialisedPlugins.has(id)) continue;
    const existingInit = initialisingPlugins.get(id);
    if (existingInit) {
      await existingInit;
      continue;
    }
    const loader = pluginInitLoaders.get(id);
    if (!loader) continue;
    const pending = Promise.resolve()
      .then(() => loader())
      .then(init => init({
          addHook: pluginInitContext!.addHook,
          HookPoints: pluginInitContext!.HookPoints,
          pluginId: id,
        }))
      .then(() => {
        initialisedPlugins.add(id);
      })
      .catch(err => {
        console.error(`[plugin] Failed to init ${id}:`, err);
      })
      .finally(() => {
        initialisingPlugins.delete(id);
      });
    initialisingPlugins.set(id, pending);
    await pending;
  }
}

/**
 * Check if a plugin is activated
 */
export function isPluginActive(ctx: HookContext, pluginId: string): boolean {
  return ctx.activatedPlugins.has(pluginId);
}

/**
 * Get all available plugins
 */
export function getAvailablePlugins(ctx: HookContext): PluginInfo[] {
  const plugins: PluginInfo[] = [];
  for (const [, info] of pluginRegistry) {
    plugins.push({
      ...info,
      isActive: ctx.activatedPlugins.has(info.id),
    });
  }
  return plugins;
}

/**
 * Get a specific plugin
 */
export function getPlugin(pluginId: string): PluginInfo | undefined {
  return pluginRegistry.get(pluginId);
}

/** Find the plugin that owns a generic plugin-admin page slug. */
export function getPluginForAdminPage(slug: string): PluginInfo | undefined {
  for (const info of pluginRegistry.values()) {
    if (info.manifest.adminPage === slug) return info;
  }
  return undefined;
}

/**
 * Get plugin count
 */
export function getPluginCount(): number {
  return pluginRegistry.size;
}

/**
 * Check if a plugin exists
 */
export function pluginExists(pluginId: string): boolean {
  return pluginRegistry.has(pluginId);
}

// ==================== Hook System ====================

/**
 * Register a hook handler for a specific hook point.
 * Only handlers from activated plugins will be executed.
 *
 * @param hookPoint - The hook point name (use HookPoints constants)
 * @param pluginId - The plugin ID registering this handler
 * @param handler - The handler function
 * @param priority - Execution priority (lower = earlier, default 10)
 *
 * G6-1: dedupes (pluginId, handler-by-reference) so middleware
 * bootstrap + plugin-loader injectScript registering the same plugin
 * twice doesn't end up running the handler twice on every request.
 */
export function addHook(
  hookPoint: string,
  pluginId: string,
  handler: CallHandler | FilterHandler,
  priority = 10,
): void {
  if (!hookRegistry.has(hookPoint)) {
    hookRegistry.set(hookPoint, []);
  }
  const handlers = hookRegistry.get(hookPoint)!;
  if (handlers.some(h => h.pluginId === pluginId && h.handler === handler)) {
    return;
  }
  handlers.push({ pluginId, handler, priority });
  // Keep sorted by priority
  handlers.sort((a, b) => a.priority - b.priority);
}

/**
 * Remove all hook handlers for a specific plugin
 */
export function removePluginHooks(pluginId: string): void {
  for (const [hookPoint, handlers] of hookRegistry) {
    const filtered = handlers.filter(h => h.pluginId !== pluginId);
    if (filtered.length === 0) {
      hookRegistry.delete(hookPoint);
    } else {
      hookRegistry.set(hookPoint, filtered);
    }
  }
}

/**
 * Execute a "call" hook - runs all handlers for the given hook point.
 * Only executes handlers from activated plugins.
 * 
 * @param hookPoint - The hook point name
 * @param args - Arguments to pass to handlers
 */
export async function doHook(ctx: HookContext, hookPoint: string, ...args: any[]): Promise<void> {
  if (!hasHook(ctx, hookPoint)) return;

  for (const reg of hookRegistry.get(hookPoint)!) {
    if (!ctx.activatedPlugins.has(reg.pluginId)) continue;
    try {
      await (reg.handler as CallHandler)(...args);
    } catch (err) {
      console.error(`[plugin] Error in hook ${hookPoint} from plugin ${reg.pluginId}:`, err);
    }
  }
}

/**
 * Execute a "filter" hook - passes a value through all handlers.
 * Each handler receives the current value and must return the (possibly modified) value.
 * Only executes handlers from activated plugins.
 *
 * @param ctx - Request context (or minimal HookContext)
 * @param hookPoint - The hook point name
 * @param value - The initial value to filter
 * @param args - Additional arguments to pass to handlers
 * @returns The filtered value
 */
export async function applyFilter(ctx: HookContext, hookPoint: string, value: any, ...args: any[]): Promise<any> {
  if (!hasHook(ctx, hookPoint)) return value;

  let result = value;
  for (const reg of hookRegistry.get(hookPoint)!) {
    if (!ctx.activatedPlugins.has(reg.pluginId)) continue;
    try {
      result = await (reg.handler as FilterHandler)(result, ...args);
    } catch (err) {
      console.error(`[plugin] Error in filter ${hookPoint} from plugin ${reg.pluginId}:`, err);
      throw err;
    }
  }
  return result;
}

/**
 * Execute a filter hook while isolating plugin failures.
 * Use only for non-critical presentation hooks where missing plugin output is
 * preferable to failing the entire page.
 */
export async function applyFilterSafely(ctx: HookContext, hookPoint: string, value: any, ...args: any[]): Promise<any> {
  if (!hasHook(ctx, hookPoint)) return value;

  let result = value;
  for (const reg of hookRegistry.get(hookPoint)!) {
    if (!ctx.activatedPlugins.has(reg.pluginId)) continue;
    try {
      result = await (reg.handler as FilterHandler)(result, ...args);
    } catch (err) {
      console.error(`[plugin] Error in safe filter ${hookPoint} from plugin ${reg.pluginId}:`, err);
    }
  }
  return result;
}

/**
 * Run safe filter handlers until one returns a value accepted by `stopWhen`.
 * This is for single-owner operations such as mail delivery, where continuing
 * after a successful adapter would duplicate an external side effect.
 */
export async function applyFilterUntil(
  ctx: HookContext,
  hookPoint: string,
  value: any,
  stopWhen: (value: any) => boolean,
  ...args: any[]
): Promise<any> {
  if (!hasHook(ctx, hookPoint)) return value;

  let result = value;
  for (const reg of hookRegistry.get(hookPoint)!) {
    if (!ctx.activatedPlugins.has(reg.pluginId)) continue;
    try {
      result = await (reg.handler as FilterHandler)(result, ...args);
      if (stopWhen(result)) return result;
    } catch (err) {
      console.error(`[plugin] Error in short-circuit filter ${hookPoint} from plugin ${reg.pluginId}:`, err);
    }
  }
  return result;
}

/**
 * Check if a hook point has any registered handlers
 */
export function hasHook(ctx: HookContext, hookPoint: string): boolean {
  const handlers = hookRegistry.get(hookPoint);
  if (!handlers) return false;
  return handlers.some(h => ctx.activatedPlugins.has(h.pluginId));
}

/**
 * Get all registered hook points (for debugging/admin)
 */
export function getRegisteredHooks(): Map<string, { pluginId: string; priority: number }[]> {
  const result = new Map<string, { pluginId: string; priority: number }[]>();
  for (const [hookPoint, handlers] of hookRegistry) {
    result.set(hookPoint, handlers.map(h => ({
      pluginId: h.pluginId,
      priority: h.priority,
    })));
  }
  return result;
}

// ==================== Plugin Activation Helpers ====================

/**
 * Serialize activated plugins list to string for DB storage
 */
export function serializeActivatedPlugins(ctx: HookContext): string {
  return JSON.stringify(Array.from(ctx.activatedPlugins));
}

/**
 * Parse activated plugins list from DB string
 */
export function parseActivatedPlugins(value: string | null | undefined): string[] {
  if (!value) return [];
  try {
    const arr = JSON.parse(value);
    return Array.isArray(arr) ? arr.filter(id => typeof id === 'string') : [];
  } catch {
    return [];
  }
}

// ==================== Client Snippets ====================

/**
 * Collect client-side HTML snippets from all activated plugins.
 *
 * Plugins register their frontend output by hooking into:
 *   - archive:header (filter): receives current headHtml, returns headHtml with appended content
 *   - archive:footer (filter): receives current bodyHtml, returns bodyHtml with appended content
 *
 * This function applies both filters and returns the aggregated result.
 * Themes should call this once and inject the HTML into <head> and before </body>.
 *
 * @param options - Site options object from loadOptions()
 * @returns {{ headHtml: string, bodyHtml: string }}
 */
export interface PageContext {
  /** Whether the current page includes a comment form */
  hasComments?: boolean;
  /** Page type hint for plugins */
  pageType?: 'index' | 'post' | 'page' | 'archive' | 'search' | 'notfound';
}

export interface ClientSnippetContext {
  user?: { uid?: number; group?: string } | null;
  isLoggedIn?: boolean;
  csrfToken?: string | null;
}

export async function getClientSnippets(
  ctx: HookContext,
  options: Record<string, any>,
  pageContext?: PageContext,
  clientContext?: ClientSnippetContext,
): Promise<{ headHtml: string; bodyHtml: string }> {
  const extra = {
    options,
    pageContext,
    ...clientContext,
    csrfToken: (ctx as HookContext & { csrfToken?: string | null }).csrfToken,
  };
  let headHtml = await applyFilterSafely(ctx, 'archive:header', '', extra);
  let bodyHtml = await applyFilterSafely(ctx, 'archive:footer', '', extra);
  return { headHtml, bodyHtml };
}

// ==================== Plugin Configuration ====================

/**
 * Check if a plugin has configuration fields defined in its manifest.
 */
export function pluginHasConfig(pluginId: string): boolean {
  const info = pluginRegistry.get(pluginId);
  if (!info) return false;
  return !!info.manifest.config && Object.keys(info.manifest.config).length > 0;
}

/**
 * Resolve the plugins-list 「设置」href for a plugin, or null when none.
 * Prefer a custom admin settings page (`adminPageIsSettings`) over the
 * declarative plugin-config form.
 */
export function getPluginSettingsHref(pluginId: string): string | null {
  const info = pluginRegistry.get(pluginId);
  if (!info) return null;
  const { adminPage, adminPageIsSettings } = info.manifest;
  if (adminPageIsSettings && adminPage) {
    return `/admin/plugin/${encodeURIComponent(adminPage)}`;
  }
  if (pluginHasConfig(pluginId)) {
    return `/admin/plugin-config?id=${encodeURIComponent(pluginId)}`;
  }
  return null;
}

/** Document title for `/admin/plugin/[slug]` when a owning plugin is found. */
export function getPluginAdminPageTitle(plugin: PluginInfo): string {
  const { name, adminPageTitle, adminPageIsSettings } = plugin.manifest;
  if (adminPageTitle) return adminPageTitle;
  if (adminPageIsSettings && name) return `${name} 设置`;
  return name || plugin.id;
}

/**
 * Resolve the initial values for a Typecho-style configuration definition.
 * Theme and plugin manifests use the same field contract, so keep this
 * normalization in one place.
 */
export function getConfigDefaults(
  configDef?: Record<string, PluginConfigField>,
): Record<string, any> {
  if (!configDef) return {};

  const defaults: Record<string, any> = {};
  for (const [key, field] of Object.entries(configDef)) {
    if (field.default !== undefined) {
      defaults[key] = field.default;
    } else if (field.type === 'checkbox') {
      defaults[key] = field.options ? [] : '0';
    } else if (field.type === 'repeatable') {
      defaults[key] = [];
    } else {
      defaults[key] = '';
    }
  }
  return defaults;
}

/**
 * Get default values from plugin's config definition.
 * Returns a flat object { fieldName: defaultValue }.
 */
export function getPluginConfigDefaults(pluginId: string): Record<string, any> {
  const info = pluginRegistry.get(pluginId);
  return getConfigDefaults(info?.manifest.config);
}

/**
 * Parse a plugin configuration form according to the plugin manifest.
 */
export function parsePluginConfigFormData(
  configDef: Record<string, PluginConfigField>,
  formData: FormData,
): Record<string, any> {
  const settings: Record<string, any> = {};
  for (const [key, field] of Object.entries(configDef)) {
    if (field.type === 'checkbox') {
      if (field.options) {
        // Typecho's Checkbox element submits multi-value fields as `name[]`.
        // Keep accepting the historical unbracketed name for existing plugin
        // forms that have not yet adopted the Typecho-compatible markup.
        const values = formData.getAll(`${key}[]`);
        settings[key] = (values.length > 0 ? values : formData.getAll(key)).map(v => v.toString());
      } else {
        // Boolean toggle: "1" when checked, "0" when unchecked
        settings[key] = formData.has(key) ? '1' : '0';
      }
    } else if (field.type === 'repeatable') {
      settings[key] = parseRepeatableField(key, field, formData);
    } else {
      settings[key] = formData.get(key)?.toString() ?? '';
    }
  }
  return settings;
}

function parseRepeatableField(
  key: string,
  field: PluginConfigField,
  formData: FormData,
): Record<string, any>[] {
  const itemFields = field.itemFields || {};
  const rows = new Map<number, Record<string, any>>();
  const pattern = new RegExp(`^${escapeRegExp(key)}\\[(\\d+)\\]\\[([^\\]]+)\\]$`);

  for (const [name, value] of formData.entries()) {
    const match = name.match(pattern);
    if (!match) continue;

    const index = Number(match[1]);
    const itemKey = match[2];
    if (!Number.isInteger(index) || !itemFields[itemKey]) continue;

    const row = rows.get(index) || {};
    const itemField = itemFields[itemKey];
    if (itemField.type === 'checkbox') {
      row[itemKey] = formData.getAll(name).map(v => v.toString());
    } else {
      row[itemKey] = value.toString();
    }
    rows.set(index, row);
  }

  return [...rows.entries()]
    .sort(([a], [b]) => a - b)
    .map(([, row]) => applyRepeatableDefaults(row, itemFields))
    .filter(row => Object.values(row).some(value => {
      if (Array.isArray(value)) return value.length > 0;
      return String(value ?? '').trim() !== '';
    }));
}

function applyRepeatableDefaults(
  row: Record<string, any>,
  itemFields: Record<string, PluginConfigField>,
): Record<string, any> {
  const result: Record<string, any> = {};
  for (const [key, field] of Object.entries(itemFields)) {
    if (row[key] !== undefined) {
      result[key] = row[key];
    } else if (field.default !== undefined) {
      result[key] = field.default;
    } else if (field.type === 'checkbox') {
      result[key] = [];
    } else {
      result[key] = '';
    }
  }
  return result;
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Load plugin configuration from the options table.
 * Key format: "plugin:<pluginId>", value is a JSON string.
 * Falls back to defaults from manifest if not yet saved.
 *
 * @param options - Site options object from loadOptions() (contains all option rows)
 * @param pluginId - Plugin identifier
 * @returns Merged config object (saved values + defaults for missing keys)
 */
export function loadPluginConfig(
  options: Record<string, any>,
  pluginId: string,
): Record<string, any> {
  const defaults = getPluginConfigDefaults(pluginId);
  const raw = options?.[`plugin:${pluginId}`];

  if (!raw) return { ...defaults };

  try {
    const saved = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return { ...defaults, ...saved };
  } catch {
    return { ...defaults };
  }
}

// ==================== Shared Plugin Utilities ====================

/**
 * Parse a plugin config value from the options store.
 * Handles both raw objects and JSON-encoded strings.
 */
export function parsePluginOption(value: unknown, label?: string): Record<string, unknown> {
  if (!value) return {};
  if (typeof value === 'object') return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    const parsed = JSON.parse(value) as unknown;
    return parsed && typeof parsed === 'object' ? parsed as Record<string, unknown> : {};
  } catch {
    if (label) console.error(`[${label}] Failed to parse plugin config`);
    return {};
  }
}

/**
 * Escape a string for use in HTML attribute values.
 */
export { escapeAttr } from '@/lib/escape';

export { getClientIp } from '@/lib/client-ip';
