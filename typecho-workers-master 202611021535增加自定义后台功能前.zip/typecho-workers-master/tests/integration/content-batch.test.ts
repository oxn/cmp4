/**
 * Integration tests for POST /api/admin/content-batch
 *
 * Covers: delete and mark actions for posts and pages.
 * Verifies auth guards, permission checks, meta count adjustments, and redirects.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { inArray } from 'drizzle-orm';
import * as schema from '@/db/schema';
import { createTestDb, seedAdmin, makeAuthCookie, type TestDatabase } from '../helpers';

// ---- shared DB ref -----------------------------------------------------------

let testDb: TestDatabase;

vi.mock('@/db', async () => {
  const actual = await vi.importActual<typeof import('@/db')>('@/db');
  return { ...actual, getDb: (_d1: any) => testDb, schema: actual.schema };
});
vi.mock('@/lib/auth', async () => {
  const actual = await vi.importActual<typeof import('@/lib/auth')>('@/lib/auth');
  return { ...actual, requireAdminCSRF: async () => null };
});

vi.mock('@/lib/plugin', () => ({
  parseActivatedPlugins: () => [],
  setActivatedPlugins: () => {},
  applyFilter: async (_ctx: any, _hook: string, data: any) => data,
  doHook: async () => {},
}));

import { POST } from '@/pages/api/admin/content-batch';

// ---- helpers -----------------------------------------------------------------

const TEST_SECRET = 'content-batch-secret';
const TEST_AUTH_CODE = 'contentbatchcode';

async function seedPost(
  db: TestDatabase,
  overrides: Partial<typeof schema.contents.$inferInsert> = {},
  authorId = 1,
) {
  const slug = overrides.slug || `post-${Date.now()}-${Math.random()}`;
  await db.insert(schema.contents).values({
    title: 'Test Post',
    slug,
    created: Math.floor(Date.now() / 1000),
    type: 'post',
    status: 'publish',
    allowComment: '1',
    authorId,
    ...overrides,
  });
  return (await db.query.contents.findFirst({
    where: (t, { eq }) => eq(t.slug, slug),
  }))!;
}

function makeBatchRequest(
  action: string,
  cids: number[],
  cookieHeader: string,
  extraParams: Record<string, string> = {},
  referer = 'https://example.com/admin/manage-posts',
): Request {
  const params = new URLSearchParams({ do: action, ...extraParams });
  const urlStr = `https://example.com/api/admin/content-batch?${params}`;
  const body = new URLSearchParams();
  for (const cid of cids) body.append('cid[]', String(cid));
  return new Request(urlStr, {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: cookieHeader,
      referer,
    },
    body: body.toString(),
  });
}

function makePageSortRequest(cids: number[], cookieHeader: string, parent = '0'): Request {
  const body = new URLSearchParams({ parent });
  for (const cid of cids) body.append('cid[]', String(cid));
  return new Request('https://example.com/api/admin/content-batch?do=sort&type=page', {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: cookieHeader,
      referer: 'https://example.com/admin/manage-pages',
    },
    body: body.toString(),
  });
}

// ---- tests -------------------------------------------------------------------

describe('POST /api/admin/content-batch', () => {
  beforeEach(async () => {
    testDb = await createTestDb();
  });

  // -- Auth guards --

  it('returns 401 when no cookie', async () => {
    await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const req = makeBatchRequest('delete', [1], '');
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(401);
  });

  it('returns 403 when user is not contributor', async () => {
    const user = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'visitor' });
    const cookie = await makeAuthCookie(testDb, user.uid, TEST_AUTH_CODE, TEST_SECRET);
    const req = makeBatchRequest('delete', [1], cookie);
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(403);
  });

  it('redirects to referer when no cids are submitted', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const req = makeBatchRequest('delete', [], cookie);
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(302);
  });

  // -- delete action --

  it('deletes selected posts', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const p1 = await seedPost(testDb, { slug: 'p1' });
    const p2 = await seedPost(testDb, { slug: 'p2' });

    const req = makeBatchRequest('delete', [p1.cid!, p2.cid!], cookie);
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(302);

    const remaining = await testDb.select().from(schema.contents);
    expect(remaining).toHaveLength(0);
  });

  it('also deletes associated comments and fields when deleting post', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'post-with-comments' });

    // Add a comment and a field
    await testDb.insert(schema.comments).values({
      cid: post.cid!,
      author: 'Alice',
      text: 'Hello',
      status: 'approved',
      type: 'comment',
      created: 1,
    });
    await testDb.insert(schema.fields).values({
      cid: post.cid!,
      name: 'custom_field',
      type: 'str',
      str_value: 'value',
    });

    const req = makeBatchRequest('delete', [post.cid!], cookie);
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const comments = await testDb.select().from(schema.comments);
    expect(comments).toHaveLength(0);

    const fields = await testDb.select().from(schema.fields);
    expect(fields).toHaveLength(0);
  });

  it('decrements meta count when post with category relationship is deleted', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'categorized-post' });

    // Add a category with count=2
    await testDb.insert(schema.metas).values({
      name: 'Tech',
      slug: 'tech',
      type: 'category',
      count: 2,
    });
    const cat = (await testDb.query.metas.findFirst())!;
    await testDb.insert(schema.relationships).values({ cid: post.cid!, mid: cat.mid });

    const req = makeBatchRequest('delete', [post.cid!], cookie);
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const updatedCat = await testDb.query.metas.findFirst();
    expect(updatedCat?.count).toBe(1);
  });

  it('contributor can only delete their own posts', async () => {
    // Admin (uid=1) is the owner; contributor (uid=2) tries to delete admin's post
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'contributor' });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);

    // Seed a post owned by a different (non-existent) user id=99
    const post = await seedPost(testDb, { slug: 'other-post', authorId: 99 });

    const req = makeBatchRequest('delete', [post.cid!], cookie);
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    // Post should NOT be deleted since contributor doesn't own it
    const remaining = await testDb.select().from(schema.contents);
    expect(remaining).toHaveLength(1);
  });

  // -- mark action --

  it('returns 403 when contributor tries to mark status', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'contributor' });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'contrib-post' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'hidden' });
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(403);
  });

  it('editor can mark post status to publish', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'draft-post', status: 'waiting' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'publish' });
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(302);

    const updated = await testDb.query.contents.findFirst();
    expect(updated?.status).toBe('publish');
  });

  it('editor can mark post status to hidden', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'visible-post', status: 'publish' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'hidden' });
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const updated = await testDb.query.contents.findFirst();
    expect(updated?.status).toBe('hidden');
  });

  it('editor can mark post status to waiting', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'pub-post', status: 'publish' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'waiting' });
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const updated = await testDb.query.contents.findFirst();
    expect(updated?.status).toBe('waiting');
  });

  it('editor can mark post status to private', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'pub-post-2', status: 'publish' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'private' });
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const updated = await testDb.query.contents.findFirst();
    expect(updated?.status).toBe('private');
  });

  it('rejects invalid status value', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const post = await seedPost(testDb, { slug: 'status-test', status: 'publish' });

    const req = makeBatchRequest('mark', [post.cid!], cookie, { status: 'evil' });
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    // Status must remain unchanged when invalid status is given
    const updated = await testDb.query.contents.findFirst();
    expect(updated?.status).toBe('publish');
  });

  it('marks multiple posts in one request', async () => {
    const editor = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE, group: 'editor' });
    const cookie = await makeAuthCookie(testDb, editor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const p1 = await seedPost(testDb, { slug: 'multi-1', status: 'publish' });
    const p2 = await seedPost(testDb, { slug: 'multi-2', status: 'publish' });

    const req = makeBatchRequest('mark', [p1.cid!, p2.cid!], cookie, { status: 'hidden' });
    await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    const all = await testDb.select().from(schema.contents);
    expect(all.every(p => p.status === 'hidden')).toBe(true);
  });

  // -- page batch (type=page) --

  it('deletes pages when type=page is specified', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const page = await seedPost(testDb, { slug: 'my-page', type: 'page' });

    const req = makeBatchRequest('delete', [page.cid!], cookie, { type: 'page' });
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(302);

    const remaining = await testDb.select().from(schema.contents);
    expect(remaining).toHaveLength(0);
  });

  it('redirects to manage-pages when type=page after operation', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);

    // No cids → redirect immediately
    const req = makeBatchRequest('delete', [], cookie, { type: 'page' }, 'https://example.com/admin/manage-pages');
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
    expect(res.status).toBe(302);
    expect(res.headers.get('location')).toContain('manage-pages');
  });

  // -- page sorting --

  it('persists the Typecho page drag order for the current parent', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const first = await seedPost(testDb, { slug: 'first-page', type: 'page', parent: 0, order: 9 });
    const second = await seedPost(testDb, { slug: 'second-page', type: 'page', parent: 0, order: 3 });

    const req = makePageSortRequest([second.cid!, first.cid!], cookie);
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ success: 1, message: '页面排序已经完成' });
    const pages = await testDb.select({ cid: schema.contents.cid, order: schema.contents.order })
      .from(schema.contents)
      .where(inArray(schema.contents.cid, [first.cid!, second.cid!]));
    expect(new Map(pages.map(page => [page.cid, page.order]))).toEqual(new Map([
      [second.cid!, 1],
      [first.cid!, 2],
    ]));
  });

  it('rejects page ordering with duplicate IDs, a wrong parent, or a non-page ID', async () => {
    const admin = await seedAdmin(testDb, { secret: TEST_SECRET, authCode: TEST_AUTH_CODE });
    const cookie = await makeAuthCookie(testDb, admin.uid, TEST_AUTH_CODE, TEST_SECRET);
    const rootPage = await seedPost(testDb, { slug: 'root-sort-page', type: 'page', parent: 0, order: 7 });
    const childPage = await seedPost(testDb, { slug: 'child-sort-page', type: 'page', parent: rootPage.cid, order: 8 });
    const post = await seedPost(testDb, { slug: 'not-a-sort-page', type: 'post', parent: 0, order: 9 });

    for (const req of [
      makePageSortRequest([rootPage.cid!, rootPage.cid!], cookie),
      makePageSortRequest([childPage.cid!], cookie, '0'),
      makePageSortRequest([post.cid!], cookie),
    ]) {
      const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);
      expect(res.status).toBe(400);
    }

    const unchanged = await testDb.query.contents.findFirst({ where: (table, { eq }) => eq(table.cid, rootPage.cid!) });
    expect(unchanged?.order).toBe(7);
  });

  it('requires editor permission to persist page ordering', async () => {
    const contributor = await seedAdmin(testDb, {
      secret: TEST_SECRET,
      authCode: TEST_AUTH_CODE,
      group: 'contributor',
    });
    const cookie = await makeAuthCookie(testDb, contributor.uid, TEST_AUTH_CODE, TEST_SECRET);
    const page = await seedPost(testDb, { slug: 'contributor-page', type: 'page', parent: 0, order: 6 });

    const req = makePageSortRequest([page.cid!], cookie);
    const res = await POST({ request: req, locals: {}, url: new URL(req.url) } as any);

    expect(res.status).toBe(403);
    const unchanged = await testDb.query.contents.findFirst({ where: (table, { eq }) => eq(table.cid, page.cid!) });
    expect(unchanged?.order).toBe(6);
  });
});
